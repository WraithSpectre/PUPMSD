-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2023 at 09:14 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pupmsd`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `blood_pressure` varchar(255) NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `complaint` text NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `staff_in_charge` varchar(255) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `blood_pressure`, `temperature`, `complaint`, `appointment_date`, `appointment_time`, `staff_in_charge`, `patient_id`, `created_at`, `updated_at`) VALUES
(1, '100', 0.00, 'saet ulo', '2023-11-20', '18:47:00', 'kuya', 2, '2023-11-20 10:47:18', '2023-11-20 10:47:18'),
(3, '100', 0.00, 'm kn', '2023-11-21', '23:04:00', 'kuya', 9, '2023-11-21 15:04:35', '2023-11-21 15:04:35'),
(4, '100', 0.00, 'MATARAY', '2023-11-22', '10:46:00', 'si ate', 10, '2023-11-22 02:47:01', '2023-11-22 02:47:01'),
(6, '100/80', 0.00, 'fever', '2023-11-24', '16:39:00', 'Dr. Kimba', 11, '2023-11-24 08:40:20', '2023-11-24 08:40:20');

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

CREATE TABLE `consultation` (
  `consultation_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `medication` varchar(255) DEFAULT NULL,
  `prescription` text DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultation`
--

INSERT INTO `consultation` (`consultation_id`, `patient_id`, `appointment_id`, `medication`, `prescription`, `notes`) VALUES
(21, 2, 1, NULL, '2 capsules of Diatabs', 'Wag iinom');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_title` varchar(255) NOT NULL,
  `acted_by` varchar(50) NOT NULL,
  `action_made` varchar(255) NOT NULL,
  `action_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medical_history`
--

CREATE TABLE `medical_history` (
  `record_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `diagnosis` varchar(200) DEFAULT NULL,
  `symptoms` varchar(200) DEFAULT NULL,
  `treatment` varchar(200) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medical_staff`
--

CREATE TABLE `medical_staff` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `specialization` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_staff`
--

INSERT INTO `medical_staff` (`user_id`, `first_name`, `last_name`, `email`, `pass`, `specialization`) VALUES
(13, 'Tester', 'Account', 'testaccount12!@gmail.com', '$2y$10$qwQh0rRhybyYVc2RNaZL1eBWxaBx2ZzdVSI8uNqN.0Y6jx4mYHuQu', 'admin'),
(14, 'Arnel', 'Marasigan', 'arnelmarasigan.work1@gmail.com', '$2y$10$9Ht.B1r.JjzChoyLJvFMi.rnprJNQpq7EdEuGoU3cfBp1MwvV9DY2', 'faculty'),
(15, 'Joyce', 'Marilao', 'joycemarilao12@gmail.com', '$2y$10$1G6f0xfdamoRI/6r8QGSgepS5E18tkkI4yYTUZusIGrH55EjvXs0S', 'md staff');

-- --------------------------------------------------------

--
-- Table structure for table `medicine_inventory`
--

CREATE TABLE `medicine_inventory` (
  `med_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `medicine` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `consumed` int(11) NOT NULL,
  `expiration_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicine_inventory`
--

INSERT INTO `medicine_inventory` (`med_id`, `date`, `medicine`, `quantity`, `consumed`, `expiration_date`) VALUES
(10, '2023-11-24', 'antidepressant', 4, 0, '2023-11-24'),
(11, '2023-11-24', 'Biogesic', 100, 0, '2023-12-09');

-- --------------------------------------------------------

--
-- Table structure for table `med_junction`
--

CREATE TABLE `med_junction` (
  `m_id` int(11) NOT NULL,
  `consultation_id` int(11) DEFAULT NULL,
  `med_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `med_junction`
--

INSERT INTO `med_junction` (`m_id`, `consultation_id`, `med_id`) VALUES
(4, 21, 11);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('M','F','O') NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `contact_number` int(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `type` enum('Student','Staff','Faculty') NOT NULL,
  `report_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `first_name`, `last_name`, `date_of_birth`, `gender`, `address`, `contact_number`, `email`, `type`, `report_id`) VALUES
(2, 'Robert', 'Dulay', '2023-11-09', 'M', 'rthrt', 99999, 'BobD123@gmail.com', 'Student', NULL),
(9, 'Mark', 'Tangay', '2023-11-06', 'M', 'rthrt', 99999, 'danielmontales2811@gmai.com', 'Staff', NULL),
(10, 'Orion', 'Peace', '2023-11-07', 'O', 'inn99-ji9', 876564, 'uygyfrt@gmail.vom', 'Faculty', NULL),
(11, 'Frank', 'Welker', '2023-12-05', 'M', 'taguig', 922222, 'fw@gmail.com', 'Staff', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patient_information`
--

CREATE TABLE `patient_information` (
  `info_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `additional_info` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_information`
--

INSERT INTO `patient_information` (`info_id`, `patient_id`, `additional_info`) VALUES
(1, 2, 'may sakit\r\n'),
(3, 9, 'ouch'),
(5, 10, 'medical info\r\n'),
(6, 11, 'medical info');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `prescription_id` int(11) NOT NULL,
  `record_id` int(11) NOT NULL,
  `medication_name` varchar(100) NOT NULL,
  `dosage` varchar(50) DEFAULT NULL,
  `frequency` varchar(50) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `report_type` varchar(100) DEFAULT NULL,
  `generated_date` date NOT NULL,
  `report_data` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supply_inventory`
--

CREATE TABLE `supply_inventory` (
  `sup_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `supply` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `consumed` int(11) NOT NULL,
  `expiration_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supply_inventory`
--

INSERT INTO `supply_inventory` (`sup_id`, `date`, `supply`, `quantity`, `consumed`, `expiration_date`) VALUES
(1, '2023-11-23', 'band-aid', 8, 0, '2023-11-30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_equipments`
--

CREATE TABLE `tbl_equipments` (
  `id` int(11) NOT NULL,
  `general_description` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `serviceable` tinyint(1) NOT NULL,
  `nonserviceable` tinyint(1) NOT NULL,
  `nonserviceable_option` varchar(255) DEFAULT NULL,
  `need_replacement` tinyint(1) NOT NULL,
  `additional` tinyint(1) NOT NULL,
  `quantity_of_request` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `submission_date` varchar(100) NOT NULL,
  `submitted_by_1` varchar(100) NOT NULL,
  `submitted_by_2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_matrix`
--

CREATE TABLE `tbl_matrix` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `sc` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `date_of_request` varchar(255) NOT NULL,
  `date_acted_upon` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `clinic` varchar(255) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `month_yr` varchar(100) NOT NULL,
  `prepared_by` varchar(100) NOT NULL,
  `noted_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_matrix`
--

INSERT INTO `tbl_matrix` (`id`, `name`, `course`, `age`, `gender`, `sc`, `pwd`, `date_of_request`, `date_acted_upon`, `signature`, `remarks`, `clinic`, `purpose`, `month_yr`, `prepared_by`, `noted_by`) VALUES
(1, 'Sherrymae Casambros', 'BSIT 4-5', 22, 'Female', 'lorem ipsum', 'lorem ipsum', '10-04-2023', '11-07-2023', 'uploads//ESignature-Casambros, Sherrymae C.jpg', 'done', '', '', '', '', ''),
(2, 'Gurdheep Hampal', 'BSIT 4-5', 22, 'Male', 'lorem ipsum', 'lorem ipsum', '10-03-2023', '10-06-2023', 'uploads//ESignature-Hampal, Gurdheep.jpg', 'done', '', '', '', '', ''),
(3, 'Daniel Montales', 'BSIT 4-5', 23, 'Male', 'lorem ipsum', 'lorem ipsum', '10-30-2023', '10-31-2023', 'uploads//ESignature-Montales, Daniel.jpg', 'done', '', '', '', '', ''),
(4, 'Solene Smith', 'BSA 1-3', 19, 'Female', 'lorem ipsum', 'lorem ipsum', '11-03-2023', '11-07-2023', 'uploads//ESignature-Smith, Solene.jpg', 'done', '', '', '', '', ''),
(1, 'Sherrymae Casambros', 'BSIT 4-5', 22, 'Female', 'lorem ipsum', 'lorem ipsum', '10-04-2023', '11-07-2023', 'uploads//ESignature-Casambros, Sherrymae C.jpg', 'done', 'Mabini Campus College Medical Clinic', 'Documentation', 'November 2023', 'Nurse Jane Santos', 'Dr. Miguel Austria'),
(2, 'Gurdheep Hampal', 'BSIT 4-5', 22, 'Male', 'lorem ipsum', 'lorem ipsum', '10-03-2023', '10-06-2023', 'uploads//ESignature-Hampal, Gurdheep.jpg', 'done', '', '', '', '', ''),
(3, 'Daniel Montales', 'BSIT 4-5', 23, 'Male', 'lorem ipsum', 'lorem ipsum', '10-30-2023', '10-31-2023', 'uploads//ESignature-Montales, Daniel.jpg', 'done', '', '', '', '', ''),
(4, 'Solene Smith', 'BSA 1-3', 19, 'Female', 'lorem ipsum', 'lorem ipsum', '11-03-2023', '11-07-2023', 'uploads//ESignature-Smith, Solene.jpg', 'done', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_matrix_findings`
--

CREATE TABLE `tbl_matrix_findings` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `sc` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `date_of_request` varchar(255) NOT NULL,
  `date_acted_upon` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `md_signature` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `clinic` varchar(255) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `month_yr` varchar(100) NOT NULL,
  `prepared_by` varchar(100) NOT NULL,
  `noted_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_matrix_findings`
--

INSERT INTO `tbl_matrix_findings` (`id`, `name`, `course`, `age`, `gender`, `sc`, `pwd`, `date_of_request`, `date_acted_upon`, `signature`, `md_signature`, `remarks`, `clinic`, `purpose`, `month_yr`, `prepared_by`, `noted_by`) VALUES
(1, 'Sherrymae Casambros', 'BSIT 4-5', 22, 'Female', 'lorem ipsum', 'lorem ipsum', '10-17-2023', '11-09-2023', 'uploads//ESignature-Casambros, Sherrymae.jpg', 'uploads//M.D. Signature.jpg', 'with mild scoliosis', 'Mabini Campus College Medical Clinic', 'Documentation', 'November 2023', 'Nurse Jane Santos', 'Dr. Miguel Austria'),
(2, 'Gurdheep Hampal', 'BSIT 4-5', 22, 'Male', 'lorem ipsum', 'lorem ipsum', '10-23-2023', '10-25-2023', 'uploads//ESignature-Hampal, Gurdheep.jpg', 'uploads//M.D. Signature.jpg', 'all normal', '', '', '', '', ''),
(3, 'Daniel Montales', 'BSIT 4-5', 22, 'Male', 'lorem ipsum', 'lorem ipsum', '11-03-2023', '11-06-2023', 'uploads//ESignature-Montales, Daniel.jpg', 'uploads//M.D. Signature.jpg', 'all normal', '', '', '', '', ''),
(4, 'Solene Smith', 'BSA 1-3', 19, 'Female', 'lorem ipsum', 'lorem ipsum', '11-14-2023', '11-17-2023', 'uploads//ESignature-Smith, Solene.jpg', 'uploads//M.D. Signature.jpg', 'with asthma', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supply`
--

CREATE TABLE `tbl_supply` (
  `id` int(6) NOT NULL,
  `date` varchar(255) NOT NULL,
  `clinic` varchar(100) NOT NULL,
  `campus` varchar(100) NOT NULL,
  `medicines` varchar(100) NOT NULL,
  `m_quantity` varchar(255) NOT NULL,
  `m_date_received` varchar(255) NOT NULL,
  `m_remarks` text NOT NULL,
  `supplies` varchar(100) NOT NULL,
  `s_quantity` varchar(255) NOT NULL,
  `s_date_received` varchar(255) NOT NULL,
  `s_remarks` text NOT NULL,
  `prepared_by` varchar(100) NOT NULL,
  `noted_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_supply`
--

INSERT INTO `tbl_supply` (`id`, `date`, `clinic`, `campus`, `medicines`, `m_quantity`, `m_date_received`, `m_remarks`, `supplies`, `s_quantity`, `s_date_received`, `s_remarks`, `prepared_by`, `noted_by`) VALUES
(1, '2023-11-25', 'Mabini Campus College Medical Clinic', 'PUP - Sta. Mesa, Manila', 'Paracetamol', '50 boxes', '2023-11-06', '500 mg tablets', 'Latex Gloves', '100 boxes', '2023-11-06', 'disposable gloves', 'Nurse Jane Santos', 'Dr. Miguel Austria'),
(2, '0000-00-00', '', '', 'Symdex-D Forte', '30 boxes', '2023-11-07', '500 mg / 25 mg / 2 mg tablets', 'Bandage Wrap', '500 pcs', '2023-11-07', 'self-adhesive bandage wrap', '', ''),
(3, '0000-00-00', '', '', 'Biogesic', '50 boxes', '2023-11-07', '500 mg tablet', 'Gauze Bandage', '1000 boxes', '2023-11-07', '4x10 yards', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

CREATE TABLE `user_access` (
  `user_id` int(11) NOT NULL,
  `access_level` varchar(50) DEFAULT NULL,
  `module` varchar(100) DEFAULT NULL,
  `access_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `consultation`
--
ALTER TABLE `consultation`
  ADD PRIMARY KEY (`consultation_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `appointment_id` (`appointment_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `medical_history`
--
ALTER TABLE `medical_history`
  ADD PRIMARY KEY (`record_id`),
  ADD UNIQUE KEY `patient_id` (`patient_id`);

--
-- Indexes for table `medical_staff`
--
ALTER TABLE `medical_staff`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `medicine_inventory`
--
ALTER TABLE `medicine_inventory`
  ADD PRIMARY KEY (`med_id`);

--
-- Indexes for table `med_junction`
--
ALTER TABLE `med_junction`
  ADD PRIMARY KEY (`m_id`),
  ADD KEY `consultation_id` (`consultation_id`),
  ADD KEY `med_id` (`med_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`),
  ADD KEY `report_id` (`report_id`);

--
-- Indexes for table `patient_information`
--
ALTER TABLE `patient_information`
  ADD PRIMARY KEY (`info_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`prescription_id`),
  ADD UNIQUE KEY `record_id` (`record_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `supply_inventory`
--
ALTER TABLE `supply_inventory`
  ADD PRIMARY KEY (`sup_id`);

--
-- Indexes for table `user_access`
--
ALTER TABLE `user_access`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `consultation`
--
ALTER TABLE `consultation`
  MODIFY `consultation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medical_history`
--
ALTER TABLE `medical_history`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medical_staff`
--
ALTER TABLE `medical_staff`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `medicine_inventory`
--
ALTER TABLE `medicine_inventory`
  MODIFY `med_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `med_junction`
--
ALTER TABLE `med_junction`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `patient_information`
--
ALTER TABLE `patient_information`
  MODIFY `info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `prescription_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supply_inventory`
--
ALTER TABLE `supply_inventory`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_access`
--
ALTER TABLE `user_access`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `consultation`
--
ALTER TABLE `consultation`
  ADD CONSTRAINT `consultation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  ADD CONSTRAINT `consultation_ibfk_2` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`);

--
-- Constraints for table `medical_history`
--
ALTER TABLE `medical_history`
  ADD CONSTRAINT `medical_history_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `med_junction`
--
ALTER TABLE `med_junction`
  ADD CONSTRAINT `med_junction_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultation` (`consultation_id`),
  ADD CONSTRAINT `med_junction_ibfk_2` FOREIGN KEY (`med_id`) REFERENCES `medicine_inventory` (`med_id`);

--
-- Constraints for table `patients`
--
ALTER TABLE `patients`
  ADD CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `report` (`report_id`) ON DELETE CASCADE;

--
-- Constraints for table `patient_information`
--
ALTER TABLE `patient_information`
  ADD CONSTRAINT `patient_information_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `prescription_ibfk_1` FOREIGN KEY (`record_id`) REFERENCES `medical_history` (`record_id`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_access` (`user_id`);

--
-- Constraints for table `user_access`
--
ALTER TABLE `user_access`
  ADD CONSTRAINT `user_access_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `medical_staff` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
