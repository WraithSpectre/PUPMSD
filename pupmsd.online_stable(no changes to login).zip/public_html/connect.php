<?php
$host = "localhost";
$username = "u868151448_sherry";
$password = "04202002Pjs";
$database = "u868151448_pupmsd";

$mysqli = new mysqli($host, $username, $password, $database);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>