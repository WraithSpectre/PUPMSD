<?php
include '../connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $bloodPressure = isset($_POST['blood_pressure']) ? $_POST['blood_pressure'] : '';
    $temperature = isset($_POST['temperature']) ? $_POST['temperature'] : '';
    $complaint = isset($_POST['complaint']) ? $_POST['complaint'] : '';
    $appointment_date = isset($_POST['appointment_date']) ? $_POST['appointment_date'] : '';
    $appointment_time = isset($_POST['appointment_time']) ? $_POST['appointment_time'] : '';
    $staffInCharge = isset($_POST['staff_in_charge']) ? $_POST['staff_in_charge'] : '';
    $notes = isset($_POST['notes']) ? $_POST['notes'] : '';
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $patientId = isset($_POST['patient_id']) ? $_POST['patient_id'] : '';
    $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : ''; // Assuming you have a user_id parameter
    
    

    // Check if a consultation with the same patient, date, and time already exists
    $checkUniqueQuery = "SELECT * FROM appointments WHERE patient_id = ? AND appointment_date = ? AND appointment_time = ?";
    $stmtCheckUnique = $mysqli->prepare($checkUniqueQuery);
    $stmtCheckUnique->bind_param("iss", $patientId, $appointment_date, $appointment_time);
    $stmtCheckUnique->execute();
    $resultCheckUnique = $stmtCheckUnique->get_result();

    if ($resultCheckUnique->num_rows > 0) {
        // A consultation with the same patient, date, and time already exists
        echo "Error: A consultation with the same patient, date, and time already exists.";
    } else {
        // Insert into the consultation table
        $insertConsultationQuery = "INSERT INTO appointments (patient_id, blood_pressure, temperature, complaint, appointment_date, appointment_time, staff_in_charge, notes, status, user_id)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($insertConsultationQuery);
        $stmt->bind_param("issssssssi", $patientId, $bloodPressure, $temperature, $complaint, $appointment_date, $appointment_time, $staffInCharge, $notes, $status, $user_id);
        
        if ($stmt->execute()) {
            // Rest of your code...
        } else {
            echo "Error adding consultation data: " . $mysqli->error;
        }
    }

    // Close prepared statements
    $stmtCheckUnique->close();
    $stmt->close();
} else {
    echo "Invalid request.";
}

$mysqli->close();
?>
