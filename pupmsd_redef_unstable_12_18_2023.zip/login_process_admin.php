<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'connect.php';

$email = $_POST['email'];
$pass = $_POST['pass'];

echo "You attempted to login with " . $email . " and " . $pass. "<br>";

$stmt = $mysqli->prepare("SELECT admin_id, email, pass, account_status FROM admin WHERE email = ?");
$stmt->bind_param("s", $email);
echo "Email: " . $email . "<br>";

$stmt->execute();
$stmt->store_result();

$stmt->bind_result($admin_id, $email, $stored_password, $account_status);

if ($stmt->num_rows == 1) {
    echo "I found one person with that email.<br>";

    if ($stmt->fetch() && password_verify($pass, $stored_password)) {
        echo "The Password Matches";
        echo "Login Success<br>";

        $_SESSION['email'] = $email;
        $_SESSION['admin_id'] = $admin_id;

        // ob_end_clean();

        if ($account_status === "active") {
            header("Location: ./admin/index.php");
        } elseif ($account_status === "inactive") {
            header("Location: index.php");
        } 
        else {
            header("Location: index.php");
        }

        exit;
    } else {
        $_SESSION = [];
        session_destroy();
        header("Location: index.php");
        exit;
    }
} else {
    $_SESSION = [];
    session_destroy();
    header("Location: index.php");
    exit;
}

?>