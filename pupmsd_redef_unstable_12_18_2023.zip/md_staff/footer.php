<Head>
    <style>
        body {
            position: relative;
            min-height: 100vh;
        }

        /* Your existing styles for the footer */
        footer {
            text-align: center;
            color: black;
            /* Additional styles for positioning at the bottom */
            position: absolute;
            bottom: 0;
            width: 100%;
            background-color: #b7b7b7;
        }
    </style>
</Head>

<!-- Footer -->
  <footer>
    <div class="text-center p-3">
      &copy; 2023 Polytechnic University of the Philippines. All rights reserved.
    </div>
  </footer>



  
</html>
